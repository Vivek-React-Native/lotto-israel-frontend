import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {Platform, StatusBar} from 'react-native';
import {useAppSelector} from './Redux/store/store';
import AppStack from './Stacks/AppStack';
import AuthStack from './Stacks/AuthStack';

const Main = () => {
  const {isAuthenticated} = useAppSelector(state => state.global);
  return (
    <NavigationContainer>
      <StatusBar
        barStyle={Platform.OS === 'ios' ? 'dark-content' : 'light-content'}
      />
      {isAuthenticated ? <AppStack /> : <AuthStack />}
    </NavigationContainer>
  );
};

export default Main;
