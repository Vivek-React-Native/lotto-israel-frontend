import {Pressable, PressableProps, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {HEIGHT} from '../../Constants/deviceDimensions';

type Props = PressableProps & {
  type?: 'price' | 'number';
  text: string;
  color1: string;
  color2: string;
  textColor?: string;
  fontSize?: number;
};

const TwoColoredButton = ({
  type,
  color1,
  color2,
  textColor,
  text,
  fontSize,
  ...rest
}: Props) => {
  return (
    <Pressable
      style={[
        styles.blackAndGrayBtn,
        type === 'number'
          ? {height: responsiveHeight(30), width: responsiveHeight(20)}
          : {height: responsiveHeight(30), width: responsiveHeight(160)},
      ]}
      {...rest}>
      <View style={[styles.gray, {backgroundColor: color1}]} />
      <View style={[styles.black, {backgroundColor: color2}]} />
      <Text
        style={[
          styles.btnText,
          {
            color: textColor ? textColor : 'white',
            fontSize: responsiveHeight(fontSize ? fontSize : 20),
          },
        ]}>
        {text}
      </Text>
    </Pressable>
  );
};

export default TwoColoredButton;

const styles = StyleSheet.create({
  blackAndGrayBtn: {
    borderWidth: 1.2,
    borderColor: COLORS.WHITE,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 1,
  },
  gray: {
    width: '99%',
    height: '50%',
    position: 'absolute',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    top: 0,
  },
  black: {
    width: '99%',
    height: '50%',
    position: 'absolute',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    bottom: 0,
  },
  btnText: {
    color: COLORS.WHITE,
  },
});
