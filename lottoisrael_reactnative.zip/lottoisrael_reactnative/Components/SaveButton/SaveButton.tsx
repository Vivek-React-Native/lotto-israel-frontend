import {
  ImageRequireSource,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableOpacityProps,
  View,
} from 'react-native';
import React from 'react';
import {normalize, responsiveHeight} from '../../Helpers/responsiveFunctions';
import {COLORS} from '../../Constants/colors';

type Props = TouchableOpacityProps & {
  text: string;
  color: string;
  width: number;
  height: number;
};

const SaveButton = ({text, color, width, height, ...rest}: Props) => {
  return (
    <TouchableOpacity
      style={[
        styles.button,
        {backgroundColor: color, width: width, height: height},
      ]}
      {...rest}>
      <View />
      <Text style={styles.text}>{text}</Text>
    </TouchableOpacity>
  );
};

export default SaveButton;

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    alignSelf: 'center',
    paddingVertical: responsiveHeight(12),
    marginVertical: responsiveHeight(10),
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    paddingHorizontal: responsiveHeight(15),
    opacity: 1,
    zIndex: 100,
    borderWidth: normalize(2),
    borderColor: 'white',
  },
  text: {
    color: COLORS.WHITE,
    fontWeight: '400',
    left: normalize(-50),
    fontSize: normalize(24),
    top: normalize(-3),
  },
});
