import {

  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
} from 'react-native';
import React from 'react';
import {COLORS} from '../../Constants/colors';
import {WIDTH} from '../../Constants/deviceDimensions';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';

type Props = {
  label: string;
  containerStyle?: StyleProp<ViewStyle>;
  name: string;
  isRequired?: boolean;
  defaultValue?: string;
  placeHolder?: string;
  bold?: boolean;
  numericKeyBoard?: boolean;
  onTextChanged: (field: string, value: string) => void;
  onError?: boolean;
};

const AddCardInput = ({
  label,
  containerStyle,
  name,
  isRequired,
  defaultValue,
  placeHolder,
  numericKeyBoard,
  onTextChanged,
  onError = false,
}: Props) => {
  return (
    <View style={[styles.container, containerStyle, onError && styles.error]}>
      <Text style={styles.label}>{isRequired ? label + '*' : label}</Text>
      <TextInput
        defaultValue={defaultValue}
        style={[styles.input]}
        placeholder={placeHolder}
        placeholderTextColor={COLORS.modalBackground}
        keyboardType={numericKeyBoard ? 'numeric' : 'default'}
        onChangeText={value => onTextChanged(name, value)}
      />
    </View>
  );
};

export default AddCardInput;

const styles = StyleSheet.create({
  container: {
    width: WIDTH * 0.85,
    alignSelf: 'center',
    alignItems: 'flex-start',
    justifyContent: 'center',
    backgroundColor: COLORS.WHITE,
    height: responsiveHeight(40),
    borderRadius: 10,
    marginVertical: 15,
  },
  input: {
    writingDirection: 'rtl',
    direction: 'rtl',
    marginLeft: 10,
    fontWeight: '400',
    fontSize: 16,
  },
  label: {
    color: COLORS.WHITE,
    writingDirection: 'rtl',
    position: 'absolute',
    fontWeight: '500',
    fontSize: responsiveHeight(16),
    top: -20,
  },
  error: {
    borderWidth: 1,
    borderColor: 'red',
  },
});
