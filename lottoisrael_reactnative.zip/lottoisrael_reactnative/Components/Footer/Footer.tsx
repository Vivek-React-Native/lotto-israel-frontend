import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import TwoColoredButton from '../TwoColoredButton/TwoColoredButton';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {useTranslation} from 'react-i18next';
type Props = {
  isExtra?: boolean;
};

const Footer = ({isExtra}: Props) => {
  const {t} = useTranslation();
  return (
    <View style={styles.bottom}>
      <View style={{justifyContent: 'space-around', height: '100%'}}>
        <TwoColoredButton
          color1={COLORS.GRAY_5}
          color2={COLORS.BLACK}
          text="₪850"
          style={styles.twoColoredButtons}
        />
        <TwoColoredButton
          color1={COLORS.GRAY_1}
          text={t('submitForm')}
          color2={COLORS.WHITE}
          type="number"
          style={styles.twoColoredButtons}
          textColor={COLORS.BLACK}
        />
        <Text style={styles.totalPaymentText}>{t('totalPayment')}</Text>
      </View>
      <View style={{height: '100%', justifyContent: 'space-evenly'}}>
        <Text style={{color: COLORS.WHITE}}>{t('summary')}</Text>
        <Text style={{color: COLORS.WHITE}}>{t('tables')}</Text>
        <Text style={{color: COLORS.WHITE}}>{t('raffles')}</Text>
        {isExtra && <Text style={styles.extra}>{t('extra')}</Text>}
      </View>
    </View>
  );
};

export default Footer;

const styles = StyleSheet.create({
  bottom: {
    position: 'absolute',
    bottom: 0,
    width: WIDTH,
    height: responsiveHeight(100),
    flexDirection: 'row-reverse',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
    paddingHorizontal: 25,
    paddingVertical: 5,
    backgroundColor: COLORS.RED_4,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  totalPaymentText: {
    color: COLORS.WHITE,
    position: 'absolute',
    right: HEIGHT < 700 ? responsiveHeight(115) : responsiveHeight(92),
  },

  twoColoredButtons: {
    width: HEIGHT < 700 ? responsiveHeight(110) : responsiveHeight(90),
    alignItems: 'center',
    height: HEIGHT < 700 ? responsiveHeight(40) : responsiveHeight(30),
    justifyContent: 'center',
  },
  extra: {
    color: COLORS.RED_4,
    backgroundColor: COLORS.YELLOW_1,
    position: 'absolute',
    left: responsiveHeight(70),
    bottom: 10,
    width: responsiveHeight(70),
    textAlign: 'center',
    paddingVertical: 5,
    fontWeight: '700',
  },
});
