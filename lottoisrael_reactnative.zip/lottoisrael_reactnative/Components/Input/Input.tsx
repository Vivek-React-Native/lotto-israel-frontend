import {
  NativeSyntheticEvent,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  TextInputFocusEventData,
  TextInputProps,
  View,
  ViewStyle,
} from 'react-native';
import React, {useState} from 'react';
import {COLORS} from '../../Constants/colors';
import {WIDTH, HEIGHT} from '../../Constants/deviceDimensions';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';

type Props = {
  label: string;
  containerStyle?: StyleProp<ViewStyle>;
  name: string;
  isRequired?: boolean;
  defaultValue?: string;
  placeHolder?: string;
  bold?: boolean;
  keyboardType?: TextInputProps['keyboardType'];
  onTextChanged: (field: string, value: string) => void;
  onError?: boolean;
};

const Input = ({
  label,
  containerStyle,
  name,
  isRequired,
  defaultValue,
  placeHolder,
  keyboardType,
  onTextChanged,
  onError = false,
}: Props) => {
  const handleTextChange = (value: string) => onTextChanged(name, value);
  return (
    <View style={[styles.container, containerStyle, onError && styles.error]}>
      <Text style={styles.label}>{isRequired ? label + '*' : label}</Text>
      <TextInput
        defaultValue={defaultValue}
        style={[styles.input]}
        placeholder={placeHolder}
        placeholderTextColor={COLORS.modalBackground}
        keyboardType={keyboardType}
        onChangeText={handleTextChange}
      />
    </View>
  );
};

export default Input;

const styles = StyleSheet.create({
  container: {
    width: WIDTH * 0.85,
    alignSelf: 'center',
    alignItems: 'flex-start',
    justifyContent: 'center',
    backgroundColor: COLORS.WHITE,
    height: HEIGHT < 700 ? responsiveHeight(50) : responsiveHeight(40),
    borderRadius: 10,
    marginVertical: 15,
    zIndex: 100,
  },
  input: {
    writingDirection: 'rtl',
    direction: 'rtl',
    marginLeft: 10,
    width: WIDTH * 0.85,
    borderRadius: 10,
    height: '100%',
    textAlign: 'right',
  },
  label: {
    color: COLORS.WHITE,
    writingDirection: 'rtl',
    position: 'absolute',
    fontWeight: '500',
    fontSize: responsiveHeight(16),
    top: -20,
  },
  error: {
    borderWidth: 1,
    borderColor: 'red',
  },
});
