import {
  Image,
  ImageRequireSource,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableOpacityProps,
  View,
} from 'react-native';
import React from 'react';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {COLORS} from '../../Constants/colors';
import {WIDTH} from '../../Constants/deviceDimensions';

type Props = TouchableOpacityProps & {
  text: string;
  logo: ImageRequireSource;
  color: string;
};

const LoginButton = ({text, logo, color, ...rest}: Props) => {
  return (
    <TouchableOpacity
      style={[styles.button, {backgroundColor: color}]}
      {...rest}>
      <View />
      <Text style={styles.text}>{text}</Text>
      <Image source={logo} style={styles.logo} resizeMode="contain" />
    </TouchableOpacity>
  );
};

export default LoginButton;

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    width: WIDTH * 0.85,
    alignSelf: 'center',
    paddingVertical: responsiveHeight(12),
    marginVertical: responsiveHeight(10),
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    paddingHorizontal: responsiveHeight(15),
    opacity: 1,
    zIndex: 100,
  },
  logo: {
    width: responsiveHeight(25),
    height: responsiveHeight(25),
    marginRight: 10,
  },
  text: {
    color: COLORS.WHITE,
    fontWeight: '700',
    marginRight: -10,
  },
});
