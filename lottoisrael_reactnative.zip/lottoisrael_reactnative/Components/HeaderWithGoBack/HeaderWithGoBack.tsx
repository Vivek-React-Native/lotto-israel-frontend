import {
  StyleProp,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import React from 'react';
import {COLORS} from '../../Constants/colors';
import {WIDTH} from '../../Constants/deviceDimensions';
import {useNavigation} from '@react-navigation/native';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';

type Props = {
  onGoBackPressed?: () => void;
  title?: string | null;
  leftItem?: React.ReactElement | React.ReactNode;
  centerItem?: React.ReactElement | React.ReactNode;
  headerContainerStyle?: StyleProp<ViewStyle>;
};

const HeaderWithGoBack = ({
  onGoBackPressed,
  title,
  leftItem,
  centerItem,
  headerContainerStyle,
}: Props) => {
  const navigation = useNavigation();
  const handleBackPress = () => {
    if (navigation.canGoBack()) navigation.goBack();
    onGoBackPressed && onGoBackPressed();
  };
  return (
    <View style={[styles.container, headerContainerStyle]}>
      <TouchableOpacity style={styles.rightArrow} onPress={handleBackPress} />
      {title && <Text style={styles.title}>{title}</Text>}
      {centerItem && centerItem}
      {leftItem && leftItem}
    </View>
  );
};

export default HeaderWithGoBack;

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    direction: 'rtl',
    writingDirection: 'rtl',
    width: WIDTH * 0.97,
    alignSelf: 'center',
    marginBottom: 20,
    marginTop: 10,
    minHeight: responsiveHeight(50),
  },
  rightArrow: {
    borderRightWidth: 2,
    borderTopWidth: 2,
    transform: [{rotate: '135deg'}],
    width: responsiveHeight(15),
    height: responsiveHeight(15),
    borderColor: COLORS.WHITE,
    marginLeft: responsiveHeight(20),
  },
  title: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(22),
    fontWeight: '600',
    position: 'absolute',
    left: responsiveHeight(40),
  },
});
