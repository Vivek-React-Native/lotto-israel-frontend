import {
  StyleProp,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import React from 'react';
import {HEIGHT} from '../../Constants/deviceDimensions';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {COLORS} from '../../Constants/colors';

type Props = {
  value: number;
  isSelected: boolean;
  onSelect: (value: number) => void;
  style?: StyleProp<ViewStyle>;
};

const NumberOfTableSelector = ({isSelected, onSelect, value, style}: Props) => {
  return (
    <TouchableOpacity
      style={[
        styles.number,
        {
          backgroundColor: isSelected ? COLORS.BLUE_4 : COLORS.WHITE,

          borderColor: isSelected ? COLORS.BLUE_4 : COLORS.RED_5,
        },
        style,
      ]}
      onPress={() => onSelect(value)}>
      <Text
        style={{
          color: isSelected ? COLORS.WHITE : COLORS.RED_5,
          fontWeight: '700',
          fontSize: responsiveHeight(20),
        }}>
        {value}
      </Text>
    </TouchableOpacity>
  );
};

export default NumberOfTableSelector;

const styles = StyleSheet.create({
  number: {
    margin: 5,
    width: HEIGHT < 700 ? responsiveHeight(75) : responsiveHeight(65),
    height: HEIGHT < 700 ? responsiveHeight(75) : responsiveHeight(65),
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 5,
      height: 2,
    },
    shadowOpacity: 0.65,
    shadowRadius: 3,
    elevation: 15,
  },
});
