import {
  Animated,
  Easing,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useEffect, useRef} from 'react';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import LinearGradient from 'react-native-linear-gradient';
import {COLORS} from '../../Constants/colors';

type Props = {
  redButtonText: string;
  whiteButtonText: string;
  description: string;
  isOpen: boolean;
  onRedButtonPressed?: () => void;
  onWhiteButtonPressed?: () => void;
};

const ErrorModal = ({
  redButtonText,
  whiteButtonText,
  description,
  isOpen,
  onRedButtonPressed,
  onWhiteButtonPressed,
}: Props) => {
  const scale = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (isOpen) {
      Animated.timing(scale, {
        useNativeDriver: true,
        duration: 300,
        toValue: 1,
        easing: Easing.elastic(0.5),
      }).start();
    } else {
      Animated.timing(scale, {
        useNativeDriver: true,
        duration: 300,
        toValue: 0,
        easing: Easing.elastic(0.5),
      }).start();
    }
  }, [isOpen]);

  return (
    <Animated.View style={[styles.container, {transform: [{scale}]}]}>
      <Text style={styles.description}>{description}</Text>
      <View style={styles.buttons}>
        <LinearGradient
          onTouchEnd={onRedButtonPressed}
          style={styles.linear}
          colors={['#FA585D', '#C0081C']}
          start={{
            x: 0,
            y: 0,
          }}
          end={{
            x: 0,
            y: 1,
          }}>
          <Text style={styles.redButtonText}>{redButtonText}</Text>
        </LinearGradient>
        <Pressable style={styles.whiteButton} onPress={onWhiteButtonPressed}>
          <Text style={styles.whiteButtonText}>{whiteButtonText}</Text>
        </Pressable>
      </View>
    </Animated.View>
  );
};

export default ErrorModal;

const styles = StyleSheet.create({
  container: {
    width: WIDTH * 0.75,
    minHeight: responsiveHeight(130),
    borderRadius: 10,
    position: 'absolute',
    top: HEIGHT * 0.4,
    backgroundColor: COLORS.modalBackground,
    paddingVertical: responsiveHeight(30),
    paddingHorizontal: responsiveHeight(10),
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 100,
  },
  buttons: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row-reverse',
  },
  redButtonText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(20),
  },
  description: {
    color: COLORS.errorText,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '600',
    fontSize: responsiveHeight(18),
  },
  linear: {
    padding: 10,
    borderRadius: 10,
    paddingHorizontal: responsiveHeight(12),
    height: responsiveHeight(50),
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.WHITE,
  },
  whiteButton: {
    backgroundColor: COLORS.WHITE,
    paddingHorizontal: responsiveHeight(12),
    height: responsiveHeight(50),
    borderRadius: 10,
    maxWidth: '60%',
    textAlign: 'center',
    justifyContent: 'center',
  },
  whiteButtonText: {
    fontSize: responsiveHeight(17),
    textAlign: 'center',
  },
});
