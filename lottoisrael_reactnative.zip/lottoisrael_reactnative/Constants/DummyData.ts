export const Dummy = '';

export const DummyLottoResults = [
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 8,
    date: '06/09/22 21:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [15, 1, 2, 32, 23, 17],
    strongNumber: 5,
    date: '07/09/22 20:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [32, 26, 22, 13, 3, 17],
    strongNumber: 3,
    date: '08/09/22 23:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [25, 26, 32, 12, 23, 27],
    strongNumber: 4,
    date: '09/09/22 18:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 9,
    date: '06/09/22 22:00',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 6,
    date: '06/09/22 21:00',
    aNumber: 3504,
  },
  {
    selectedNumbers: [25, 26, 32, 12, 23, 27],
    strongNumber: 4,
    date: '09/09/22 18:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 9,
    date: '06/09/22 22:00',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 6,
    date: '06/09/22 21:00',
    aNumber: 3504,
  },
  {
    selectedNumbers: [25, 26, 32, 12, 23, 27],
    strongNumber: 4,
    date: '09/09/22 18:59',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 9,
    date: '06/09/22 22:00',
    aNumber: 3504,
  },
  {
    selectedNumbers: [5, 16, 12, 32, 33, 37],
    strongNumber: 6,
    date: '06/09/22 21:00',
    aNumber: 3504,
  },
];
