export type InitialState = {
  isLoading: boolean;
  success: boolean;
  error: boolean;
  isAuthenticated: boolean;
  message: string;
  user: IUser;
};

export type ILogin = {
  email: string;
  password: string;
};
export type ICreditCard = {
  cardNumber: string;
  cardHolderName: string;
  exparationDate: string;
  cvc: number;
};
export type IUser = {
  fullName: string;
  creditCardInfo?: ICreditCard;
  dateOfBirth?: string;
};
