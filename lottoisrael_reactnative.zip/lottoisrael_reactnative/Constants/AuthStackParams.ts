export type AuthStackParams = {
  LoginScreen: undefined;
};
