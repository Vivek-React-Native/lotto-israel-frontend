export type AppStackParams = {
  DummyScreen: undefined;
  HomeScreen: undefined;
  CreditCardWithTokenScreen: undefined;
  BankAccountForMoneyTransferScreen: undefined;
  LottoRegularFormScreen: {
    isEditing?: boolean;
  };
  AddCreditCardScreen: undefined;
  LottoSettingsScreen: {
    headerTitle: string;
  };
  LottoShitatiFormScreen: {
    screenType?: 'regular' | 'systematic' | 'strongSystematic';
  };
  LottortResultsScreen: undefined;
  LottoSystematicFormScreen: {
    isEditing?: boolean;
  };
  StrongSystematicLotteryScreen: {
    isEditing?: boolean;
  };
};
