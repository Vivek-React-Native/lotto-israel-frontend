import React from 'react';
import {
  createStackNavigator,
  StackNavigationOptions,
} from '@react-navigation/stack';
import HomeScreen from '../Screens/Application/HomeScreen';
import {AppStackParams} from '../Constants/AppStackParams';
import CreditCardWithTokenScreen from '../Screens/Application/CreditCardWithTokenScreen';
import BankAccountForMoneyTransferScreen from '../Screens/Application/BankAccountForMoneyTransferScreen';
import DummyScreen from '../Screens/Application/DummyScreen';
import LottoRegularFormScreen from '../Screens/Application/LottoRegularFormScreen';
import AddCreditCard from '../Screens/Application/AddCreditCardScreen';
import LottoSettingsScreen from '../Screens/Application/LottoSettingsScreen';
import LottoShitatiFormScreen from '../Screens/Application/LottoShitatiFormScreen';
import LottortResultsScreen from '../Screens/Application/LottortResultsScreen';
import LottoSystematicFormScreen from '../Screens/Application/LottoSystematicFormScreen';
import StrongSystematicLotteryScreen from '../Screens/Application/StrongSystematicLotteryScreen';

const App = createStackNavigator<AppStackParams>();
const options: StackNavigationOptions = {
  headerShown: false,
};

const AppStack = () => {
  return (
    <App.Navigator screenOptions={options} initialRouteName="DummyScreen">
      <App.Screen name="DummyScreen" component={DummyScreen} />
      <App.Screen name="HomeScreen" component={HomeScreen} />
      <App.Screen name="LottoSettingsScreen" component={LottoSettingsScreen} />
      <App.Screen
        name="CreditCardWithTokenScreen"
        component={CreditCardWithTokenScreen}
      />
      <App.Screen
        name="BankAccountForMoneyTransferScreen"
        component={BankAccountForMoneyTransferScreen}
      />
      <App.Screen
        name="LottoRegularFormScreen"
        component={LottoRegularFormScreen}
      />
      <App.Screen
        name="LottoShitatiFormScreen"
        component={LottoShitatiFormScreen}
      />
      <App.Screen
        name="LottortResultsScreen"
        component={LottortResultsScreen}
      />
      <App.Screen
        name="LottoSystematicFormScreen"
        component={LottoSystematicFormScreen}
      />
      <App.Screen
        name="StrongSystematicLotteryScreen"
        component={StrongSystematicLotteryScreen}
      />
      <App.Screen name={'AddCreditCardScreen'} component={AddCreditCard} />
    </App.Navigator>
  );
};

export default AppStack;
