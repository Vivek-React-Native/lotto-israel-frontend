import React from 'react';
import {
  createStackNavigator,
  StackNavigationOptions,
} from '@react-navigation/stack';
import LoginScreen from '../Screens/Authentication/LoginScreen';
import {AuthStackParams} from '../Constants/AuthStackParams';

const Auth = createStackNavigator<AuthStackParams>();

const options: StackNavigationOptions = {
  headerShown: false,
};

const AuthStack = () => {
  return (
    <Auth.Navigator screenOptions={options}>
      <Auth.Screen name="LoginScreen" component={LoginScreen} />
    </Auth.Navigator>
  );
};

export default AuthStack;
