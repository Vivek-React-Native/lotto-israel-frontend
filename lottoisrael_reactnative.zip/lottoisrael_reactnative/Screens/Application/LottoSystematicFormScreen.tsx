import {
  Image,
  Keyboard,
  LayoutAnimation,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import TwoColoredButton from '../../Components/TwoColoredButton/TwoColoredButton';
import {useTranslation} from 'react-i18next';
import NumberOfTableSelector from '../../Components/Lotto/NumberOfTableSelector';
import Footer from '../../Components/Footer/Footer';

type Props = {
  navigation: NativeStackNavigationProp<
    AppStackParams,
    'LottoSystematicFormScreen'
  >;
  route: RouteProp<AppStackParams, 'LottoSystematicFormScreen'>;
};

const LottoSystematicFormScreen = ({navigation, route}: Props) => {
  const [selectedTab, setSelectedTab] = useState<
    'systematicDouble' | 'systematic'
  >('systematic');
  const [selectedTableNumber, setSelectedTableNumber] = useState<number>(-1);
  const {t} = useTranslation();
  return (
    <SafeAreaView style={styles.container} onTouchStart={Keyboard.dismiss}>
      <HeaderWithGoBack
        headerContainerStyle={styles.header}
        centerItem={
          <Image source={require('../../Assets/Images/HeaderCenterItem.png')} />
        }
        leftItem={
          <TouchableOpacity>
            <Image source={require('../../Assets/Images/MenuButton.png')} />
          </TouchableOpacity>
        }
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.topSection}>
          <View>
            <View style={styles.topLeft}>
              <TwoColoredButton
                color1={COLORS.GRAY_5}
                color2={COLORS.BLACK}
                type="price"
                text="₪20,000,000"
              />
              <Text style={styles.untilText}>{t('untilSaturday')}</Text>
            </View>
            <View style={styles.timeContainer}>
              <View style={styles.twoButton}>
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <Text style={styles.twoButtonText}>{t('hours')}</Text>
              </View>
              <View style={styles.twoButton}>
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <Text style={styles.twoButtonText}>{t('minutes')}</Text>
              </View>
              <View style={styles.twoButton}>
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <TwoColoredButton
                  color1={COLORS.GRAY_5}
                  color2={COLORS.BLACK}
                  type="number"
                  text="8"
                />
                <Text style={styles.twoButtonText}>{t('seconds')}</Text>
              </View>
            </View>
          </View>
          <View style={styles.topRight}>
            <Text style={styles.lotto}>{t('systematic')}</Text>
            <Text style={styles.standardText}>{t('systematicForm')}</Text>
          </View>
        </View>
        <View style={styles.tabs}>
          <TouchableOpacity
            onPress={() => {
              LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
              setSelectedTab('systematicDouble');
            }}
            style={[
              styles.doubleTab,
              {
                borderColor:
                  selectedTab === 'systematicDouble'
                    ? COLORS.WHITE
                    : COLORS.RED_5,
                backgroundColor:
                  selectedTab !== 'systematicDouble'
                    ? COLORS.RED_1
                    : COLORS.RED_5,
              },
            ]}>
            <Text style={styles.tabText}>{t('systematicDouble')}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
              setSelectedTab('systematic');
            }}
            style={[
              styles.lottoTab,
              {
                borderColor:
                  selectedTab === 'systematic' ? COLORS.WHITE : COLORS.RED_5,
                backgroundColor:
                  selectedTab !== 'systematic' ? COLORS.RED_1 : COLORS.RED_5,
              },
            ]}>
            <Text style={styles.tabText}>{t('systematic')}</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.numberOfTables}>
          <View style={styles.tableHeaderTextView}>
            <Text style={styles.tableHeaderText}>{t('selectaformtype')}</Text>
          </View>
          <View style={styles.numberContainer}>
            {[...Array(6)].map((_, index) => (
              <NumberOfTableSelector
                key={index}
                value={index + 1}
                onSelect={val => setSelectedTableNumber(val)}
                isSelected={index + 1 === selectedTableNumber}
                style={{
                  width:
                    HEIGHT < 700 ? responsiveHeight(65) : responsiveHeight(55),
                  height:
                    HEIGHT < 700 ? responsiveHeight(65) : responsiveHeight(55),
                }}
              />
            ))}
          </View>
        </View>
        <View style={styles.numberOfTables}>
          <View style={styles.tableHeaderTextView}>
            <Text style={styles.tableHeaderText}>
              {t('fill8numbersAndAStrongNumber')}
            </Text>
          </View>
          <View style={[styles.numberContainer, {justifyContent: 'center'}]}>
            <View style={styles.buttons}>
              <TouchableOpacity style={styles.clearButton}>
                <Text style={{color: COLORS.BLACK}}>{t('clearForm')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.autoFill}>
                <Text style={{color: COLORS.WHITE}}>{t('autoFill')}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <View
          style={[
            styles.table,
            {
              marginBottom: responsiveHeight(5),
              backgroundColor: route.params?.isEditing
                ? COLORS.BLUE_0
                : COLORS.RED_0,
            },
          ]}>
          <View
            style={[
              styles.table1,
              {
                backgroundColor: route.params?.isEditing
                  ? COLORS.BLUE_1
                  : COLORS.RED_4,
              },
            ]}>
            <Text
              style={{
                color: COLORS.WHITE,
                fontSize:
                  HEIGHT < 700 ? responsiveHeight(20) : responsiveHeight(16),
              }}>
              {t('table1')} ▶
            </Text>
          </View>
          <View style={styles.tableItemContainer}>
            {[...Array(37)].map((item, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.tableItem,
                  {marginRight: index === 0 ? '25%' : 0},
                ]}>
                <Text
                  style={[
                    styles.tableNumber,
                    {
                      color: route.params?.isEditing
                        ? COLORS.BLUE_1
                        : COLORS.RED_4,
                    },
                  ]}>
                  {index + 1}
                </Text>
                <Pressable
                  style={[
                    styles.tableItemBox,
                    {
                      borderColor: route.params?.isEditing
                        ? COLORS.BLUE_1
                        : COLORS.RED_4,
                    },
                  ]}
                />
              </TouchableOpacity>
            ))}
          </View>
          <View
            style={[
              styles.tableWhiteSection,
              {
                borderRightColor: route.params?.isEditing
                  ? COLORS.BLUE_1
                  : COLORS.RED_4,
              },
            ]}>
            <View
              style={[
                styles.whiteSectionArrow,
                {
                  backgroundColor: route.params?.isEditing
                    ? COLORS.BLUE_1
                    : COLORS.RED_4,
                },
              ]}>
              <Text style={{color: COLORS.WHITE}}> ▶</Text>
            </View>
            <View style={styles.tableItemContainer}>
              {[...Array(7)].map((item, index) => (
                <TouchableOpacity
                  key={index}
                  style={[
                    styles.tableItem,
                    {marginRight: index === 0 ? '45%' : 0},
                  ]}>
                  <Text
                    style={[
                      styles.tableNumber,
                      {
                        color: route.params?.isEditing
                          ? COLORS.BLUE_1
                          : COLORS.RED_4,
                      },
                    ]}>
                    {index + 1}
                  </Text>
                  <Pressable
                    style={[
                      styles.tableItemBox,
                      {
                        borderColor: route.params?.isEditing
                          ? COLORS.BLUE_1
                          : COLORS.RED_4,
                      },
                    ]}
                  />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
        {route.params?.isEditing && (
          <View style={styles.editingButtonContainer}>
            <TouchableOpacity style={styles.editingButton}>
              <Text style={styles.editingText}>{t('editing')}</Text>
            </TouchableOpacity>
          </View>
        )}
        {/* {selectedTab === 'systematicDouble' && (
          <View
            style={[
              styles.table,
              {
                marginTop: 0,
                marginBottom: responsiveHeight(75),
                backgroundColor: route.params?.isEditing
                  ? COLORS.BLUE_0
                  : COLORS.RED_0,
              },
            ]}>
            <View
              style={[
                styles.table1,
                {
                  backgroundColor: route.params?.isEditing
                    ? COLORS.BLUE_1
                    : COLORS.RED_4,
                },
              ]}>
              <Text
                style={{
                  color: COLORS.WHITE,
                  fontSize:
                    HEIGHT < 700 ? responsiveHeight(20) : responsiveHeight(16),
                }}>
                {t('table1')} ▶
              </Text>
            </View>
            <View style={styles.tableItemContainer}>
              {[...Array(37)].map((item, index) => (
                <TouchableOpacity
                  key={index}
                  style={[
                    styles.tableItem,
                    {marginRight: index === 0 ? '25%' : 0},
                  ]}>
                  <Text
                    style={[
                      styles.tableNumber,
                      {
                        color: route.params?.isEditing
                          ? COLORS.BLUE_1
                          : COLORS.RED_4,
                      },
                    ]}>
                    {index + 1}
                  </Text>
                  <Pressable
                    style={[
                      styles.tableItemBox,
                      {
                        borderColor: route.params?.isEditing
                          ? COLORS.BLUE_1
                          : COLORS.RED_4,
                      },
                    ]}
                  />
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.tableWhiteSection}>
              <View style={styles.whiteSectionArrow}>
                <Text style={{color: COLORS.WHITE}}> ▶</Text>
              </View>
              <View style={styles.tableItemContainer}>
                {[...Array(7)].map((item, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.tableItem,
                      {marginRight: index === 0 ? '45%' : 0},
                    ]}>
                    <Text
                      style={[
                        styles.tableNumber,
                        {
                          color: route.params?.isEditing
                            ? COLORS.BLUE_1
                            : COLORS.RED_4,
                        },
                      ]}>
                      {index + 1}
                    </Text>
                    <Pressable
                      style={[
                        styles.tableItemBox,
                        {
                          borderColor: route.params?.isEditing
                            ? COLORS.BLUE_1
                            : COLORS.RED_4,
                        },
                      ]}
                    />
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        )} */}
      </ScrollView>
      <Footer />
    </SafeAreaView>
  );
};

export default LottoSystematicFormScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: COLORS.RED_4,
  },
  header: {
    justifyContent: 'space-between',
    borderBottomColor: 'white',
    borderBottomWidth: 1,
    width: '100%',
  },
  topSection: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    width: WIDTH * 0.95,
  },
  topLeft: {
    flexDirection: 'row-reverse',
  },
  untilText: {
    color: COLORS.WHITE,
    marginRight: 10,
  },
  standardText: {
    fontSize: responsiveHeight(20),
    textShadowColor: 'black',
    color: COLORS.WHITE,
    textShadowOffset: {
      width: -1,
      height: 2,
    },
    textShadowRadius: 0.5,
    textAlign: 'left',
  },
  topRight: {
    justifyContent: 'space-between',
  },
  lotto: {
    color: COLORS.WHITE,
    textAlign: 'left',
    fontSize: responsiveHeight(20),
    fontWeight: '600',
  },
  timeContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    width: responsiveHeight(160),
    alignSelf: 'flex-end',
    marginTop: 5,
  },
  twoButton: {
    flexDirection: 'row-reverse',
    justifyContent: 'center',
  },
  twoButtonText: {
    position: 'absolute',
    bottom: -15,
    fontSize: responsiveHeight(12),
    color: COLORS.WHITE,
  },
  tabs: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 25,
    width: WIDTH * 0.95,
  },
  doubleTab: {
    width: '50%',
    height: HEIGHT < 700 ? responsiveHeight(52) : responsiveHeight(42),
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.2,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 10,
  },
  lottoTab: {
    width: '50%',
    height: HEIGHT < 700 ? responsiveHeight(52) : responsiveHeight(42),
    alignItems: 'center',
    borderWidth: 1.2,
    justifyContent: 'center',
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 10,
  },
  tabText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(18),
  },
  numberOfTables: {
    borderRadius: 10,
    borderColor: COLORS.WHITE,
    marginTop: 20,
    alignItems: 'flex-start',
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  numberContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: WIDTH * 0.95,
    backgroundColor: COLORS.WHITE,
  },
  tableHeaderText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(20),
    padding: 5,
    textAlign: 'left',
  },
  buttons: {
    backgroundColor: COLORS.WHITE,
    height: HEIGHT < 700 ? responsiveHeight(60) : responsiveHeight(50),
    flexDirection: 'row-reverse',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    width: '90%',
  },
  clearButton: {
    backgroundColor: COLORS.WHITE,
    borderWidth: 1.5,
    borderRadius: 10,
    borderColor: COLORS.BLACK,
    justifyContent: 'center',
    alignItems: 'center',
    height: responsiveHeight(30),
    width: '35%',
  },
  autoFill: {
    backgroundColor: COLORS.BLACK,
    borderWidth: 1.5,
    borderRadius: 10,
    borderColor: COLORS.BLACK,
    justifyContent: 'center',
    alignItems: 'center',
    height: responsiveHeight(30),
    width: '35%',
  },
  table: {
    marginTop: 15,

    borderColor: COLORS.WHITE,
    borderWidth: 1.5,
    borderRadius: 10,
    width: WIDTH * 0.95,
    alignSelf: 'center',
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  table1: {
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 10,
    flexDirection: 'row-reverse',
    width: '20%',
    position: 'absolute',
    paddingBottom: 5,
  },
  tableHeaderTextView: {
    backgroundColor: COLORS.RED_4,
    width: WIDTH * 0.95,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  tableWhiteSection: {
    backgroundColor: COLORS.WHITE,
    borderRightWidth: 1,
    width: '18%',
    flexDirection: 'row-reverse',
  },
  tableItem: {
    marginVertical: 2,
    alignItems: 'center',
    marginLeft: 9,
  },
  tableNumber: {
    fontSize: HEIGHT < 700 ? responsiveHeight(16) : responsiveHeight(12),
    marginBottom: 2,
    marginTop: -1,
  },
  tableItemBox: {
    backgroundColor: COLORS.WHITE,
    borderRadius: 12,
    height: HEIGHT < 700 ? responsiveHeight(17) : responsiveHeight(10),
    width: HEIGHT < 700 ? responsiveHeight(27) : responsiveHeight(20),

    borderWidth: 1,
  },
  whiteSectionArrow: {
    borderBottomLeftRadius: 10,
    flexDirection: 'row-reverse',
    width: HEIGHT < 700 ? responsiveHeight(27) : responsiveHeight(20),
    height: HEIGHT < 700 ? responsiveHeight(27) : responsiveHeight(20),
    position: 'absolute',
    transform: [{scale: 1.1}],
  },
  tableItemContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    flexWrap: 'wrap',
    flex: 1,
  },
  editingButton: {
    backgroundColor: COLORS.BLUE_0,
    borderColor: COLORS.BLUE_1,
    borderRadius: 20,
    borderWidth: 2,
    width: '95%',
    height: HEIGHT < 700 ? responsiveHeight(55) : responsiveHeight(45),
    alignItems: 'center',
    justifyContent: 'center',
  },
  editingButtonContainer: {
    backgroundColor: COLORS.WHITE,
    width: WIDTH * 0.95,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 5,
    marginBottom: responsiveHeight(25),
  },
  editingText: {
    color: COLORS.BLUE_1,
    fontSize: responsiveHeight(25),
  },
});
