import {
  Alert,
  Image,
  Keyboard,
  LayoutAnimation,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {useTranslation} from 'react-i18next';
import NumberOfTableSelector from '../../Components/Lotto/NumberOfTableSelector';

type Props = {
  navigation: NativeStackNavigationProp<
    AppStackParams,
    'LottoShitatiFormScreen'
  >;
  route: RouteProp<AppStackParams, 'LottoShitatiFormScreen'>;
};

const LottoShitatiFormScreen = ({navigation, route}: Props) => {
  const {t} = useTranslation();
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [selectedStrongNumber, setSelectedStrongNumber] = useState(-1);
  const [selectedStrongNumbers, setSelectedStrongNumbers] = useState<number[]>(
    [],
  );
  return (
    <SafeAreaView style={styles.container} onTouchStart={Keyboard.dismiss}>
      <HeaderWithGoBack
        headerContainerStyle={styles.header}
        title={t('table1')}
        leftItem={
          <TouchableOpacity style={styles.autoFill}>
            <Text style={{color: COLORS.WHITE}}>{t('autoFill')}</Text>
          </TouchableOpacity>
        }
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.multiLottery}>
          <Text style={styles.multiLotteryText}>
            {t('6numbersMustBeChosen')}
          </Text>
          <View style={styles.numberContainer}>
            {[...Array(37)].map((_, index) => (
              <NumberOfTableSelector
                key={index}
                value={index + 1}
                onSelect={val => {
                  if (selectedNumbers.includes(val)) {
                    let filtered = selectedNumbers.filter(item => item !== val);
                    setSelectedNumbers(filtered);
                  } else {
                    if (selectedNumbers.length < 6) {
                      setSelectedNumbers([...selectedNumbers, val]);
                    } else {
                      Alert.alert(t('youCannotSelectMoreThan6Numbers'));
                    }
                  }
                }}
                isSelected={selectedNumbers.includes(index + 1)}
                style={{
                  width:
                    HEIGHT < 700 ? responsiveHeight(70) : responsiveHeight(55),
                  height:
                    HEIGHT < 700 ? responsiveHeight(70) : responsiveHeight(55),
                }}
              />
            ))}
          </View>
        </View>
        <View style={styles.strongNumberContainer}>
          <Text style={styles.multiLotteryText}>{t('aStrongNumber')}</Text>
          {route.params?.screenType === 'strongSystematic' && (
            <Text style={[styles.multiLotteryText, {fontWeight: '700'}]}>
              {t('choose4Numbers')}
            </Text>
          )}
          <View style={styles.numberContainer}>
            {[...Array(7)].map((_, index) => (
              <NumberOfTableSelector
                key={index}
                value={index + 1}
                onSelect={val => {
                  if (route.params?.screenType === 'strongSystematic') {
                    if (selectedStrongNumbers.length < 4) {
                      setSelectedStrongNumbers([...selectedStrongNumbers, val]);
                    } else {
                      Alert.alert(t('youCannotChooseMoreThan4'));
                    }
                  } else {
                    if (val !== selectedStrongNumber) {
                      setSelectedStrongNumber(val);
                    } else {
                      setSelectedStrongNumber(-1);
                    }
                  }
                }}
                isSelected={
                  route.params?.screenType === 'strongSystematic'
                    ? selectedStrongNumbers.includes(index + 1)
                    : index + 1 === selectedStrongNumber
                }
                style={{
                  width:
                    HEIGHT < 700 ? responsiveHeight(70) : responsiveHeight(55),
                  height:
                    HEIGHT < 700 ? responsiveHeight(70) : responsiveHeight(55),
                }}
              />
            ))}
          </View>
        </View>
        <TouchableOpacity style={styles.saveButton}>
          <Text style={styles.saveButtonText}>{t('save')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

export default LottoShitatiFormScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: COLORS.RED_4,
  },
  header: {
    justifyContent: 'space-between',
    borderBottomColor: 'white',
    borderBottomWidth: 1,
    width: '100%',
  },
  multiLottery: {
    width: WIDTH * 0.95,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  multiLotteryText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(20),
    marginTop: 5,
  },
  numberContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginBottom: 5,
  },
  strongNumberContainer: {
    width: WIDTH * 0.95,
    backgroundColor: 'rgba(255, 219, 224, 0.23)',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  saveButton: {
    width: WIDTH * 0.95,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    borderColor: COLORS.RED_1,
    borderWidth: 2,
    backgroundColor: COLORS.WHITE,
    height: HEIGHT < 700 ? responsiveHeight(60) : responsiveHeight(50),
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 15,
  },
  saveButtonText: {
    fontSize: HEIGHT < 700 ? responsiveHeight(20) : responsiveHeight(18),
    color: COLORS.RED_4,
  },
  autoFill: {
    backgroundColor: COLORS.BLACK,
    borderWidth: 1.5,
    borderRadius: 8,
    borderColor: COLORS.WHITE,
    justifyContent: 'center',
    alignItems: 'center',
    height: responsiveHeight(30),
    width: responsiveHeight(130),
    marginRight: 10,
  },
});
