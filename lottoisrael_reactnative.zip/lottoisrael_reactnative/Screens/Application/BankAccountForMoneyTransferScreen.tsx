import {
  Animated,
  Easing,
  ImageBackground,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useRef} from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import Input from '../../Components/Input/Input';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {useTranslation} from 'react-i18next';

type Props = {
  navigation: NativeStackNavigationProp<
    AppStackParams,
    'BankAccountForMoneyTransferScreen'
  >;
  route: RouteProp<AppStackParams, 'BankAccountForMoneyTransferScreen'>;
};

const BankAccountForMoneyTransferScreen = ({navigation, route}: Props) => {
  const slide = useRef(new Animated.Value(0)).current;
  const {t} = useTranslation();
  useEffect(() => {
    Keyboard.addListener('keyboardDidShow', event => {
      Animated.timing(slide, {
        useNativeDriver: true,
        duration: 150,
        easing: Easing.ease,
        toValue:
          HEIGHT < 700
            ? -event.endCoordinates.height * 0.4
            : -event.endCoordinates.height * 0.2,
      }).start();
    });

    Keyboard.addListener('keyboardDidHide', event => {
      Animated.timing(slide, {
        useNativeDriver: true,
        duration: 300,
        easing: Easing.ease,
        toValue: 0,
      }).start();
    });
  }, []);

  return (
    <ImageBackground
      style={styles.bgImage}
      resizeMode="cover"
      source={require('../../Assets/Images/app-background.png')}>
      <SafeAreaView style={styles.container} onTouchStart={Keyboard.dismiss}>
        <HeaderWithGoBack title={t('bankAccountForBankTransfer')} />
        <View style={styles.descriptionContainer}>
          <Text style={styles.descriptionText}>
            {t('pleaseEnterBankAccountDetails')}
          </Text>
          <Text style={styles.descriptionText}>
            {t('weWillTransYourWinnings')}
          </Text>
          <Text style={styles.descriptionText}>
            {t('pleaseNoteWeWillTransfer')}
          </Text>
          <Text style={styles.descriptionText}>{t('itIsOver')}</Text>
        </View>
        <Animated.View
          style={{
            flex: 1,
            transform: [{translateY: slide}],
            justifyContent: 'space-between',
          }}>
          <View>
            <Input
              name="bankNumber"
              onTextChanged={(field, value) => {
                console.log('field,value: ', field, value);
              }}
              label={t('bankNumber')}
              isRequired
              containerStyle={{marginTop: responsiveHeight(28)}}
            />
            <Input
              name="branchNumber"
              onTextChanged={(field, value) => {
                console.log('field,value: ', field, value);
              }}
              label={t('branchNumber')}
              isRequired
              containerStyle={{marginTop: responsiveHeight(28)}}
            />
            <Input
              name="accountNumber"
              onTextChanged={(field, value) => {
                console.log('field,value: ', field, value);
              }}
              label={t('accountNumber')}
              isRequired
              containerStyle={{marginTop: responsiveHeight(28)}}
            />
            <Input
              name="accountInName"
              onTextChanged={(field, value) => {
                console.log('field,value: ', field, value);
              }}
              label={t('accountInName')}
              isRequired
              containerStyle={{marginTop: responsiveHeight(28)}}
            />
          </View>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>{t('save')}</Text>
          </TouchableOpacity>
        </Animated.View>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default BankAccountForMoneyTransferScreen;

const styles = StyleSheet.create({
  bgImage: {
    flex: 1,
    zIndex: 0,
    backgroundColor: COLORS.modalBackground,
    alignSelf: 'center',
    width: '100%',
  },
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    height: HEIGHT,
    alignItems: 'center',
    alignSelf: 'center',
  },
  descriptionText: {
    direction: 'rtl',
    writingDirection: 'rtl',
    color: COLORS.WHITE,
    fontSize: responsiveHeight(16),
    textAlign: 'left',
    lineHeight: 22,
  },
  descriptionContainer: {
    width: '90%',
    marginBottom: responsiveHeight(25),
  },
  buttonText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(20),
  },
  button: {
    borderColor: COLORS.WHITE,
    borderWidth: 2,
    width: WIDTH * 0.9,
    alignItems: 'center',
    justifyContent: 'center',
    height: responsiveHeight(50),
    borderRadius: 15,
    backgroundColor: COLORS.buttonBackground,
  },
});
