import {
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {normalize, responsiveHeight} from '../../Helpers/responsiveFunctions';
import {isValidIsraeliID} from '../../utils/commonMethods';
import AddCardInput from '../../Components/AddCardInput/AddCardInput';
import SaveButton from '../../Components/SaveButton/SaveButton';

type Props = {
  navigation: NativeStackNavigationProp<AppStackParams, 'AddCreditCardScreen'>;
  route: RouteProp<AppStackParams, 'AddCreditCardScreen'>;
};

const AddCreditCardScreen = ({navigation, route}: Props) => {
  const [cardNumber, setCardNumber] = useState<number>();
  const [cvv, setCvv] = useState<number>();
  const [month, setMonth] = useState<number>();
  const [year, setYear] = useState<number>();
  const [id, setId] = useState<number>();
  const [cvvError, setCvvError] = useState(false);
  const [monthError, setMonthError] = useState(false);
  const [yearError, setYearError] = useState(false);
  const [idError, setIdError] = useState(false);
  const [cardNumberError, setCardNumberError] = useState(false);
  const validateForm = (type: string, value: string) => {
    const valueLength = value?.length;
    const valueToNumber = Number(value);
    switch (type) {
      case 'cardNumber':
        {
          setCardNumber(valueToNumber);
        }
        break;
      case 'cvv':
        {
          if (valueLength === 3) {
            setCvv(valueToNumber);
            setCvvError(false);
          } else {
            setCvvError(true);
          }
        }
        break;
      case 'month':
        {
          if (
            valueToNumber > 1 &&
            valueToNumber <= 12 &&
            valueLength <= 2 &&
            valueLength > 0
          ) {
            setMonth(valueToNumber);
            setMonthError(false);
          } else {
            setMonthError(true);
          }
        }
        break;
      case 'year':
        {
          if (valueLength === 2) {
            setYear(valueToNumber);
            setYearError(false);
          } else {
            setYearError(true);
          }
        }
        break;
      case 'id':
        {
          if (isValidIsraeliID(value)) {
            setId(valueToNumber);
            setIdError(false);
          } else {
            setIdError(true);
          }
        }
        break;
    }
  };
  return (
    <ImageBackground
      style={styles.bgImage}
      resizeMode="contain"
      source={require('../../Assets/Images/app-background.png')}>
      <SafeAreaView style={styles.container}>
        <HeaderWithGoBack title="Credit Card" />
        <AddCardInput
          name="cardNumber"
          onTextChanged={(field, value) => {
            validateForm(field, value);
          }}
          label="Credit card number"
          isRequired
          containerStyle={styles.cardNumberInput}
          numericKeyBoard
          onError={cardNumberError}
        />
        <View style={styles.multiInputMainView}>
          <AddCardInput
            name="cvv"
            onTextChanged={(field, value) => {
              validateForm(field, value);
            }}
            label="CVV"
            isRequired
            containerStyle={styles.cvvInput}
            numericKeyBoard
            onError={cvvError}
          />
          <View style={styles.subView}>
            <Text style={styles.label}>Card validity *</Text>
            <AddCardInput
              name="month"
              onTextChanged={(field, value) => {
                validateForm(field, value);
              }}
              label=""
              containerStyle={styles.monthInput}
              placeHolder={'a month'}
              bold
              numericKeyBoard
              onError={monthError}
            />
            <AddCardInput
              name="year"
              onTextChanged={(field, value) => {
                validateForm(field, value);
              }}
              label=""
              containerStyle={styles.sleepInput}
              placeHolder={'sleep'}
              bold
              numericKeyBoard
              onError={yearError}
            />
          </View>
        </View>
        <AddCardInput
          name="id"
          onTextChanged={(field, value) => {
            validateForm(field, value);
          }}
          label="ID"
          isRequired
          containerStyle={styles.idInput}
          numericKeyBoard
          onError={idError}
        />
        <View style={styles.saveView}>
          <SaveButton
            text={'Save'}
            color={COLORS.YANKEES_BLUE}
            width={normalize(337)}
            height={normalize(48)}
          />
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default AddCreditCardScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
  },
  bgImage: {
    aspectRatio: 1,
    flex: 1,
    zIndex: 0,
    backgroundColor: 'black',
    alignSelf: 'center',
  },
  deleteText: {
    color: COLORS.WHITE,
    fontWeight: '700',
    fontSize: responsiveHeight(18),
    marginTop: 10,
  },
  label: {
    color: COLORS.WHITE,
    writingDirection: 'rtl',
    position: 'absolute',
    fontWeight: '500',
    fontSize: responsiveHeight(16),
    top: -5,
    left: normalize(70),
  },
  cardNumberInput: {
    width: normalize(337),
    height: normalize(50),
    top: normalize(30),
  },
  multiInputMainView: {
    flexDirection: 'row-reverse',
    left: normalize(42),
    top: normalize(60),
  },
  cvvInput: {width: normalize(100), height: normalize(50)},
  monthInput: {width: normalize(77), height: normalize(50)},
  sleepInput: {
    width: normalize(77),
    height: normalize(50),
    left: normalize(15),
  },
  idInput: {
    width: normalize(337),
    height: normalize(50),
    top: normalize(90),
  },
  subView: {flexDirection: 'row-reverse', left: normalize(70)},
  saveView: {top: normalize(120)},
});
