import {Button, SafeAreaView, StyleSheet, Text} from 'react-native';
import React, {useEffect, useMemo, useRef, useState} from 'react';
import {useAppDispatch, useAppSelector} from '../../Redux/store/store';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';

type Props = {
  navigation: NativeStackNavigationProp<AppStackParams, 'DummyScreen'>;
  route: RouteProp<AppStackParams, 'DummyScreen'>;
};

const DummyScreen = ({navigation, route}: Props) => {
  //these dummy navigation button will be removed,
  // for now just use to navigate to screen that you're working on
  return (
    <SafeAreaView>
      <Text style={{alignSelf: 'center', fontWeight: 'bold', fontSize: 25}}>
        Dummy Screen
      </Text>
      <Text
        style={{
          alignSelf: 'center',
          color: 'red',
          fontWeight: 'bold',
          textAlign: 'center',
        }}>
        {`This dummy screen will be removed \n for now just use to navigate to screen that you're working on,\n add a button down below to navigate your screen`}
      </Text>
      <Button
        title="Go To CreditCardWithTokenScreen"
        onPress={() => navigation.navigate('CreditCardWithTokenScreen')}
      />
      <Button
        title="Go To BankAccountForMoneyTransferScreen"
        onPress={() => navigation.navigate('BankAccountForMoneyTransferScreen')}
      />
      <Button
        title="Go To LottoRegularFormScreen"
        onPress={() =>
          navigation.navigate('LottoRegularFormScreen', {
            isEditing: false,
          })
        }
      />
      <Button
        title="Go To LottoSystematicFormScreen"
        onPress={() =>
          navigation.navigate('LottoSystematicFormScreen', {
            isEditing: true,
          })
        }
      />
      <Button
        title="Go To StrongSystematicLotteryScreen"
        onPress={() =>
          navigation.navigate('StrongSystematicLotteryScreen', {
            isEditing: false,
          })
        }
      />

      <Button
        title="Go To LottoSettingsScreen"
        onPress={() =>
          navigation.navigate('LottoSettingsScreen', {headerTitle: 'Lotto'})
        }
      />
      <Button
        title="Go To LottoShitatiFormScreen"
        onPress={() =>
          navigation.navigate('LottoShitatiFormScreen', {
            screenType: 'strongSystematic',
          })
        }
      />

      <Button
        title={'Add credit Card'}
        onPress={() => navigation.navigate('AddCreditCardScreen')}
      />
      <Button
        title={'Go to LottortResultsScreen'}
        onPress={() => navigation.navigate('LottortResultsScreen')}
      />
    </SafeAreaView>
  );
};

export default DummyScreen;

const styles = StyleSheet.create({});
