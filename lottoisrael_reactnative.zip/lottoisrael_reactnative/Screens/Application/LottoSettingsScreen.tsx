import {Keyboard, SafeAreaView, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {useTranslation} from 'react-i18next';
import NumberOfTableSelector from '../../Components/Lotto/NumberOfTableSelector';
import Footer from '../../Components/Footer/Footer';

type Props = {
  navigation: NativeStackNavigationProp<AppStackParams, 'LottoSettingsScreen'>;
  route: RouteProp<AppStackParams, 'LottoSettingsScreen'>;
};
const LottoSettingsScreen = ({navigation, route}: Props) => {
  const {t} = useTranslation();
  return (
    <SafeAreaView style={styles.container} onTouchStart={Keyboard.dismiss}>
      <HeaderWithGoBack
        headerContainerStyle={styles.header}
        title={route.params.headerTitle}
      />
      <View style={styles.upgrade}>
        <Text
          style={{
            color: COLORS.WHITE,
            fontSize: responsiveHeight(18),
          }}>
          {t('wannaUpgradeForm')}
        </Text>
      </View>
      <View style={styles.extra}>
        <Text
          style={{
            color: COLORS.RED_4,
            fontSize: responsiveHeight(35),
          }}>
          {t('extra')}
        </Text>
        <NumberOfTableSelector
          value={1}
          onSelect={() => {}}
          isSelected={false}
        />
      </View>
      <View style={styles.multiLottery}>
        <Text style={styles.multiLotteryText}>{t('multiLottery')}</Text>
        <View style={styles.numberContainer}>
          {[...Array(5)].map((_, index) => (
            <NumberOfTableSelector
              key={index}
              value={index + 1}
              onSelect={val => {}}
              isSelected={false}
            />
          ))}
        </View>
      </View>
      <Footer isExtra />
    </SafeAreaView>
  );
};

export default LottoSettingsScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: COLORS.RED_4,
  },
  header: {
    justifyContent: 'space-between',
    borderBottomColor: 'white',
    borderBottomWidth: 1,
    width: '100%',
  },
  upgrade: {
    width: WIDTH * 0.95,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: COLORS.RED_5,
    borderWidth: 1.5,
    borderColor: COLORS.WHITE,
    borderRadius: 10,
    height: responsiveHeight(75),
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.9,
    shadowRadius: 5,
    elevation: 10,
    marginVertical: responsiveHeight(5),
  },
  extra: {
    backgroundColor: COLORS.YELLOW_1,
    marginVertical: responsiveHeight(15),
    width: WIDTH * 0.95,
    alignItems: 'center',
    height: responsiveHeight(150),
    borderRadius: 10,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  numberContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 5,
  },
  multiLottery: {
    width: WIDTH * 0.95,
    backgroundColor: 'rgba(255, 219, 224, 0.23)',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  multiLotteryText: {
    marginBottom: 10,
    color: COLORS.WHITE,
    fontSize: responsiveHeight(20),
    marginTop: 5,
  },
});
