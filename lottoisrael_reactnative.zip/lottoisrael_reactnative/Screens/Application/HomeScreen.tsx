import {Button, SafeAreaView, StyleSheet, Text} from 'react-native';
import React, {useEffect, useMemo, useRef, useState} from 'react';
import {useAppDispatch, useAppSelector} from '../../Redux/store/store';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';

type Props = {
  navigation: NativeStackNavigationProp<AppStackParams, 'HomeScreen'>;
  route: RouteProp<AppStackParams, 'HomeScreen'>;
};

const HomeScreen = ({navigation, route}: Props) => {
  //these dummy navigation button will be removed,
  // for now just use to navigate to screen that you're working on
  return (
    <SafeAreaView>
      <Text>Home Screen</Text>
    </SafeAreaView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({});
