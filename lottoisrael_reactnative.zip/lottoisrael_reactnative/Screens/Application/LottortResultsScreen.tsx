import {
  Image,
  Keyboard,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {HEIGHT, WIDTH} from '../../Constants/deviceDimensions';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {useTranslation} from 'react-i18next';
import {DummyLottoResults} from '../../Constants/DummyData';
import TwoColoredButton from '../../Components/TwoColoredButton/TwoColoredButton';

type Props = {
  navigation: NativeStackNavigationProp<AppStackParams, 'LottortResultsScreen'>;
  route: RouteProp<AppStackParams, 'LottortResultsScreen'>;
};
const LottortResultsScreen = ({navigation, route}: Props) => {
  const {t} = useTranslation();
  return (
    <SafeAreaView style={styles.container} onTouchStart={Keyboard.dismiss}>
      <HeaderWithGoBack
        headerContainerStyle={styles.header}
        centerItem={<Text style={styles.headerTitle}>{t('lottoResults')}</Text>}
        leftItem={
          <TouchableOpacity style={styles.searchIcon}>
            <Image source={require('../../Assets/Images/search-icon.png')} />
          </TouchableOpacity>
        }
      />
      <View style={styles.tableHeader}>
        <View style={[styles.tableHeaderColumn, {width: '40%'}]}>
          <Text style={styles.tableHeaderText}>{t('lotteryNumbers')}</Text>
        </View>
        <View style={styles.tableHeaderColumn}>
          <Text style={styles.tableHeaderText}>{t('aStrongNumber')}</Text>
        </View>
        <View style={styles.tableHeaderColumn}>
          <Text style={styles.tableHeaderText}>{t('date')}</Text>
        </View>
        <View style={[styles.tableHeaderColumn, {borderLeftWidth: 0}]}>
          <Text style={styles.tableHeaderText}>{t('aNumber')}</Text>
        </View>
      </View>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollView}
        style={{
          marginBottom: 20,
        }}>
        {DummyLottoResults.map((result, index) => (
          <View
            style={[
              styles.tableRow,
              {
                borderTopWidth: index !== 0 ? 0 : undefined,
              },
            ]}
            key={index}>
            <View style={[styles.tableRowItem, {width: '40%'}]}>
              <View style={styles.resultNumbers}>
                {result.selectedNumbers.map((number, i) => (
                  <TwoColoredButton
                    key={i}
                    text={number.toString()}
                    color1={COLORS.RED_1}
                    color2={COLORS.RED_4}
                    style={styles.twoToned}
                    fontSize={
                      HEIGHT < 700 ? responsiveHeight(27) : responsiveHeight(18)
                    }
                  />
                ))}
              </View>
            </View>
            <View style={[styles.tableRowItem]}>
              <TwoColoredButton
                text={result.strongNumber.toString()}
                color1={COLORS.BLUE_3}
                color2={COLORS.BLUE_2}
                style={[styles.twoToned, {width: '22%'}]}
                fontSize={
                  HEIGHT < 700 ? responsiveHeight(27) : responsiveHeight(18)
                }
              />
            </View>
            <View style={[styles.tableRowItem]}>
              <Text style={styles.tableRowText}>
                {result.date.split(' ')[0]}
              </Text>
              <Text style={[styles.tableRowText, {color: COLORS.GRAY_4}]}>
                {result.date.split(' ')[1]}
              </Text>
            </View>
            <View style={[styles.tableRowItem, {borderLeftWidth: 0}]}>
              <Text style={styles.tableRowText}>{result.aNumber}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
};

export default LottortResultsScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: COLORS.RED_4,
  },
  header: {
    justifyContent: 'space-between',
    borderBottomColor: 'white',
    borderBottomWidth: 1,
    width: '100%',
  },
  headerTitle: {
    fontSize: responsiveHeight(20),
    color: COLORS.WHITE,
    marginLeft: 15,
  },
  tableHeader: {
    flexDirection: 'row-reverse',
    width: WIDTH * 0.97,
    alignSelf: 'center',
    backgroundColor: COLORS.RED_5,
    borderWidth: 1,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
    borderColor: COLORS.WHITE,
    height: responsiveHeight(50),
    marginBottom: 2,
  },
  tableHeaderColumn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '20%',
    borderLeftWidth: 1,
    borderLeftColor: COLORS.WHITE,
    padding: 1,
  },
  tableHeaderText: {
    color: COLORS.WHITE,
    fontSize: responsiveHeight(16),
  },
  tableRow: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row-reverse',
    width: '100%',
    borderWidth: 1,
    borderColor: COLORS.BLUE_4,
    alignSelf: 'center',
  },
  tableRowText: {
    color: COLORS.BLACK,
  },
  tableRowItem: {
    width: '20%',
    alignItems: 'center',
    justifyContent: 'center',
    borderRightColor: COLORS.BLUE_4,
    borderRightWidth: 1,
    // paddingVertical: 10,
    height: responsiveHeight(70),
  },
  resultNumbers: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row-reverse',
    width: '100%',
  },
  twoToned: {
    alignItems: 'center',
    width: '14%',
    margin: 1,
    height: HEIGHT < 700 ? responsiveHeight(40) : responsiveHeight(30),
    justifyContent: 'center',
  },
  scrollView: {
    backgroundColor: COLORS.WHITE,
    width: WIDTH * 0.97,
    flexWrap: 'wrap',
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchIcon: {
    marginRight: 15,
  },
});
