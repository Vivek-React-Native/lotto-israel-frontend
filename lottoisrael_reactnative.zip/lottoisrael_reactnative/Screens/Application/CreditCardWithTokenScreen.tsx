import {
  Button,
  ImageBackground,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {useAppDispatch, useAppSelector} from '../../Redux/store/store';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AppStackParams} from '../../Constants/AppStackParams';
import HeaderWithGoBack from '../../Components/HeaderWithGoBack/HeaderWithGoBack';
import {WIDTH} from '../../Constants/deviceDimensions';
import Input from '../../Components/Input/Input';
import {COLORS} from '../../Constants/colors';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import ErrorModal from '../../Components/ErrorModal/ErrorModal';
import {useTranslation} from 'react-i18next';

type Props = {
  navigation: NativeStackNavigationProp<
    AppStackParams,
    'CreditCardWithTokenScreen'
  >;
  route: RouteProp<AppStackParams, 'CreditCardWithTokenScreen'>;
};

const CreditCardWithTokenScreen = ({navigation, route}: Props) => {
  const {t} = useTranslation();
  const [isDeleting, setIsDeleting] = useState(false);
  const handleDelete = () => {
    setIsDeleting(true);
  };
  return (
    <ImageBackground
      style={styles.bgImage}
      resizeMode="cover"
      source={require('../../Assets/Images/app-background.png')}>
      <SafeAreaView style={styles.container}>
        <HeaderWithGoBack title={t('creditCard')} />
        <Input
          name="cardNumber"
          onTextChanged={(field, value) => {
            console.log('field,value: ', field, value);
          }}
          label={t('creditCardNumber')}
          isRequired
          defaultValue={'5637 **** **** ****'}
        />
        <TouchableOpacity onPress={handleDelete}>
          <Text style={styles.deleteText}>{t('deleteCreditCard')}</Text>
        </TouchableOpacity>
        <ErrorModal
          isOpen={isDeleting}
          description={t('areYouSureToDeleteCreditCard')}
          redButtonText={t('deleteCard')}
          whiteButtonText={t('dontWantToDelete')}
          onRedButtonPressed={() => {
            setIsDeleting(false);
          }}
          onWhiteButtonPressed={() => {
            setIsDeleting(false);
          }}
        />
      </SafeAreaView>
    </ImageBackground>
  );
};

export default CreditCardWithTokenScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    width: WIDTH,
    alignItems: 'center',
    alignSelf: 'center',
  },
  bgImage: {
    flex: 1,
    zIndex: 0,
    backgroundColor: COLORS.modalBackground,
    alignSelf: 'center',
    width: '100%',
  },
  deleteText: {
    color: COLORS.WHITE,
    fontWeight: '700',
    fontSize: responsiveHeight(18),
    marginTop: 10,
  },
});
