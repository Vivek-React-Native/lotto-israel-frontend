import {
  Animated,
  SafeAreaView,
  StyleSheet,
  View,
  Dimensions,
  Text,
  Image,
  ImageBackground,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {RouteProp} from '@react-navigation/native';
import {AuthStackParams} from '../../Constants/AuthStackParams';
import {useAppDispatch, useAppSelector} from '../../Redux/store/store';
import LoginButton from '../../Components/LoginButton/LoginButton';
import {responsiveHeight} from '../../Helpers/responsiveFunctions';
import {COLORS} from '../../Constants/colors';
import {WIDTH} from '../../Constants/deviceDimensions';
import {dummyLogin} from '../../Redux/reducers/reducers';
import {useTranslation} from 'react-i18next';

type Props = {
  navigation: NativeStackNavigationProp<AuthStackParams, 'LoginScreen'>;
  route: RouteProp<AuthStackParams, 'LoginScreen'>;
};
const LoginScreen = ({navigation, route}: Props) => {
  const {t} = useTranslation();
  const dispatch = useAppDispatch();
  const handleDummyLogin = () => {
    dispatch(dummyLogin());
  };
  return (
    <ImageBackground
      style={styles.bgImage}
      resizeMode="cover"
      source={require('../../Assets/Images/app-background.png')}>
      <SafeAreaView style={styles.container}>
        <View style={{zIndex: 100}}>
          <Image
            source={require('../../Assets/Images/logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          <View>
            <LoginButton
              text={t('signInWith') + ' Facebook '}
              logo={require('../../Assets/Images/facebook.png')}
              color={COLORS.BLUE_5}
              onPress={handleDummyLogin}
            />
            <LoginButton
              text={t('signInWith') + ' Google'}
              logo={require('../../Assets/Images/google.png')}
              color={COLORS.RED_5}
              onPress={handleDummyLogin}
            />
            <LoginButton
              text={t('connectWith') + ' Apple'}
              logo={require('../../Assets/Images/apple.png')}
              color={COLORS.GRAY_5}
              onPress={handleDummyLogin}
            />
          </View>
        </View>
        <Text style={styles.bottomText}>{t('byConnectingToTheApp')}</Text>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    direction: 'rtl',
    writingDirection: 'rtl',
    flex: 1,
    justifyContent: 'space-between',
  },
  logo: {
    alignSelf: 'center',
    marginTop: responsiveHeight(10),
    marginBottom: responsiveHeight(25),
  },
  bottomText: {
    alignSelf: 'center',
    width: WIDTH * 0.9,
    textAlign: 'center',
    color: COLORS.WHITE,
    marginBottom: responsiveHeight(10),
    fontWeight: '600',
  },
  innerText: {
    textDecorationLine: 'underline',
    fontWeight: '600',
  },
  bgImage: {
    aspectRatio: 1,
    flex: 1,
    zIndex: 0,
    backgroundColor: COLORS.modalBackground,
    alignSelf: 'center',
  },
});
