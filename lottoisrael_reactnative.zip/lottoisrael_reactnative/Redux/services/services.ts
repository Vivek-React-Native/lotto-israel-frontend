import axios from 'axios';
import {ILogin} from '../../Constants/types';

export const LoginAsync = async (data: ILogin) => {
  try {
    const response = await axios.post('endpoint will come here', data);
    return response.data;
  } catch (error) {
    return error;
  }
};
