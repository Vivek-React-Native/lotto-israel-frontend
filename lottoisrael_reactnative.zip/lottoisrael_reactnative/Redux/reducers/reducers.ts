import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import {InitialState, IUser} from '../../Constants/types';
import {login} from '../actions/actions';

export const initialState: InitialState = {
  error: false,
  success: false,
  isAuthenticated: false,
  isLoading: false,
  message: '',
  user: {} as IUser,
};

export const reducer = createSlice({
  name: 'global',
  initialState,
  reducers: {
    logout: state => {
      state.isAuthenticated = false;
      state.user = {} as IUser;
    },
    dummyLogin: state => {
      state.user = {
        fullName: 'John Doe',
        creditCardInfo: {
          cardHolderName: 'John Doe',
          cardNumber: '1111222233334444',
          cvc: 111,
          exparationDate: '11/27',
        },
        dateOfBirth: '01.01.1982',
      };
      state.isAuthenticated = true;
    },
    clearGlobalStates: state => {
      state.message = '';
      state.error = false;
      state.success = false;
    },
  },
  extraReducers: builder => {
    builder
      // *********** LOGIN START *********** \\
      .addCase(login.pending, state => {
        state.isLoading = true;
        state.message = '';
        state.success = false;
        state.error = false;
      })
      .addCase(login.fulfilled, (state, action) => {
        if (action.payload.status) {
          state.isAuthenticated = true;
          state.success = true;
        } else {
          state.message = action.payload.message;
          state.error = true;
        }
        state.isLoading = false;
      })
      .addCase(login.rejected, (state, action: any) => {
        state.error = true;
        state.isLoading = false;
        // *********** LOGIN END *********** \\
      });
  },
});

export const {logout, clearGlobalStates, dummyLogin} = reducer.actions;

export default reducer.reducer;
