import i18n from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import {initReactI18next} from 'react-i18next';
import Backend from 'i18next-http-backend';
import common_en from './Assets/Translations/en/english.json';
import common_he from './Assets/Translations/he/hebrew.json';

export default i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        common: common_en,
      },
      he: {
        common: common_he,
      },
    },
    lng: 'en',
    ns: 'common',
    defaultNS: 'common',
    fallbackNS: 'common',
    keySeparator: '.',
    interpolation: {
      escapeValue: false,
      formatSeparator: ',',
    },
    react: {
      bindI18n: 'languageChanged loaded',
      nsMode: 'default',
      useSuspense: true,
    },
    compatibilityJSON: 'v3',
  });
