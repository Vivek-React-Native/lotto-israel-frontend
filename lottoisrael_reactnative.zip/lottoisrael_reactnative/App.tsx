import {useEffect} from 'react';
import {I18nManager} from 'react-native';
import {Provider} from 'react-redux';
import Main from './Main';
import store from './Redux/store/store';
import './i18n';

const App = () => {
  useEffect(() => {
    I18nManager.forceRTL(true);
  }, []);

  return (
    <Provider store={store}>
      <Main />
    </Provider>
  );
};

export default App;
